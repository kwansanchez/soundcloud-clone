import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SimpleFormSearchLemoine")
public class SimpleFormSearchLemoine extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        try (Connection conn = DBConnectionLemoine.getDBConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT * FROM MyTableLemoine WHERE " +
                     "(? = '' OR MYUSER LIKE ?) AND " +
                     "(? = '' OR EMAIL LIKE ?) AND " +
                     "(? = '' OR PHONE LIKE ?)")) {

            String keyword = request.getParameter("keyword");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");

            // Prepare the statement with the parameters
            stmt.setString(1, keyword);
            stmt.setString(2, "%" + keyword + "%");
            stmt.setString(3, email);
            stmt.setString(4, "%" + email + "%");
            stmt.setString(5, phone);
            stmt.setString(6, "%" + phone + "%");

            ResultSet rs = stmt.executeQuery();

            out.println("<html><head><title>Search Results</title></head><body>");
            out.println("<h1>Search Results</h1>");
            out.println("<table border='1'><tr><th>ID</th><th>User</th><th>Email</th><th>Phone</th></tr>");

            while (rs.next()) {
                int id = rs.getInt("ID");
                String myuser = rs.getString("MYUSER");
                String userEmail = rs.getString("EMAIL");
                String userPhone = rs.getString("PHONE");
                out.println("<tr><td>" + id + "</td><td>" + myuser + "</td><td>" + userEmail + "</td><td>" + userPhone + "</td></tr>");
            }
            out.println("</table>");
            out.println("<a href='./search_lemoine.html' style='display: block; margin-top: 20px; text-decoration: none; padding: 10px; background-color: #f2f2f2; border: 1px solid #ccc; text-align: center;'>Search Data</a>");
            out.println("</body></html>");

            rs.close();
        } catch (SQLException se) {
            se.printStackTrace();
            out.println("<p>Error during database operation: " + se.getMessage() + "</p>");
        } catch (Exception e) {
            e.printStackTrace();
            out.println("<p>Error: " + e.getMessage() + "</p>");
        } finally {
            out.close();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}

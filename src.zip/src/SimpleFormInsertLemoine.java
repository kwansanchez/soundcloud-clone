import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SimpleFormInsertLemoine")
public class SimpleFormInsertLemoine extends HttpServlet {
    private static final long serialVersionUID = 1L;

    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
    static final String DB_URL = "jdbc:mysql://ec2-3-128-205-149.us-east-2.compute.amazonaws.com:3306/MyDBLemoine";
    static final String USER = "jlemoine";
    static final String PASS = "Stimey420!69";

    public SimpleFormInsertLemoine() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String userName = request.getParameter("userName");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");

        // Handling NULL and empty strings for optional fields
        email = (email == null || email.isEmpty()) ? null : email;
        phone = (phone == null || phone.isEmpty()) ? null : phone;
        
        try {
            Class.forName(JDBC_DRIVER);
            try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                 PreparedStatement stmt = conn.prepareStatement("INSERT INTO MyTableLemoine (MYUSER, EMAIL, PHONE) VALUES (?, ?, ?)")) {
                
                stmt.setString(1, userName);
                stmt.setString(2, email);
                stmt.setString(3, phone);
                stmt.executeUpdate();

                out.println("<html><body>");
                out.println("<h2>Data Inserted Successfully</h2>");
                out.println("<p>User Name: " + userName + "</p>");
                out.println("<p>Email: " + (email != null ? email : "NULL") + "</p>");
                out.println("<p>Phone: " + (phone != null ? phone : "NULL") + "</p>");
                out.println("<a href='/webproject-ex-0208-Lemoine/SimpleFormSearchLemoine'>Search Data</a>");
                out.println("</body></html>");
            }
        } catch (Exception e) {
            e.printStackTrace();
            out.println("<html><body><p>Error occurred: " + e.getMessage() + "</p></body></html>");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/MyServletDBLemoine")
public class MyServletDBLemoine extends HttpServlet {
    private static final long serialVersionUID = 1L;

    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
    static final String DB_URL = "jdbc:mysql://ec2-3-128-205-149.us-east-2.compute.amazonaws.com:3306/MyDBLemoine";
    static final String USER = "jlemoine";
    static final String PASS = "Stimey420!69";

    public MyServletDBLemoine() {
        super();
        // Ensure the JDBC driver is loaded
        try {
            Class.forName(JDBC_DRIVER);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        try (PrintWriter out = response.getWriter();
             Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM myTableLemoine");
             ResultSet rs = stmt.executeQuery()) {
             
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head><title>Database Servlet</title></head>");
            out.println("<body>");
            out.println("<h2>Database Results</h2>");
            
            // Iterate over the result set and display the data
            while (rs.next()) {
                String id = rs.getString("ID") != null ? rs.getString("ID") : "NULL";
                String myuser = rs.getString("MYUSER") != null ? rs.getString("MYUSER") : "NULL";
                String email = rs.getString("EMAIL") != null && !rs.getString("EMAIL").isEmpty() ? rs.getString("EMAIL") : "NULL";
                String phone = rs.getString("PHONE") != null && !rs.getString("PHONE").isEmpty() ? rs.getString("PHONE") : "NULL";

                out.println("ID: " + id + "<br>User: " + myuser + "<br>Email: " + email + "<br>Phone: " + phone + "<br><br>");
            }
            
            out.println("</body></html>");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "SQL Exception: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Exception: " + e.getMessage());
        }
    }
}

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.io.File;

public class UtilPropLemoine {
    private static Properties prop = new Properties();

    // Local development path on Windows
    static final String _PROP_FILENAME_WIN_LOCAL = "C:\\2024 Spring\\CSCI 4830 - Intro. of Software Engineering\\workspaceCSCI4830-ex-0208-Lemoine\\webproject-ex-0208-Lemoine\\WebContent\\config.properties";
    
    // Remote path for EC2 deployment
    static final String _PROP_FILENAME_REMOTE = "/home/jlemoine/myapp/webproject-ex-0208-Lemoine/WebContent/config.properties";
    
    public static void loadProperty() throws IOException {
        FileInputStream inputStream = null;
        try {
            String propFile = System.getenv("WEBAPP_CONFIG_PATH") != null ? _PROP_FILENAME_REMOTE : _PROP_FILENAME_WIN_LOCAL;
            File file = new File(propFile);
            if (file.exists()) {
                System.out.println("[DBG] Loaded: " + file.getAbsolutePath());
                inputStream = new FileInputStream(file);
            } else {
                throw new FileNotFoundException("Property file not found in the specified location: " + propFile);
            }
            prop.load(inputStream);
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
        }
    }

    public static String getProp(String key) {
        String propValue = prop.getProperty(key);
        return propValue != null ? propValue.trim() : null;
    }
}